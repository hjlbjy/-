﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _etnf.Model;

namespace _etnf.Pages
{
    /// <summary>
    /// Логика взаимодействия для MedicalCheckupPage.xaml
    /// </summary>
    public partial class MedicalCheckupPage : Page
    {
        NoEntities db;
        public MedicalCheckupPage()
        {
            InitializeComponent();
            db = new NoEntities();
            MedicalCheckupListView.ItemsSource = db.Medical_checkupTable.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AlMedical());
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var MedicalForRemoving = MedicalCheckupListView.SelectedItems.Cast<Medical_checkupTable>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следущие {MedicalForRemoving.Count()} элементы?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    db.Medical_checkupTable.RemoveRange(MedicalForRemoving);
                    db.SaveChanges();
                    MessageBox.Show("Данные удалены");
                    MedicalCheckupListView.ItemsSource = db.Medical_checkupTable.ToList();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());
                }


            }
        }
    }
}
