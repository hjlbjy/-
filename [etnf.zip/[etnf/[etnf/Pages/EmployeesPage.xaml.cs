﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _etnf.Model;

namespace _etnf.Pages
{
    /// <summary>
    /// Логика взаимодействия для EmployeesPage.xaml
    /// </summary>
    public partial class EmployeesPage : Page
    {
        NoEntities db;
        public EmployeesPage()
        {
            InitializeComponent();
            db = new NoEntities();
            EmployeesListView.ItemsSource = db.EmployeesTable.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AlEmployees());
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var EmployeesForRemoving = EmployeesListView.SelectedItems.Cast<EmployeesTable>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следущие {EmployeesForRemoving.Count()} элементы?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    db.EmployeesTable.RemoveRange(EmployeesForRemoving);
                    db.SaveChanges();
                    MessageBox.Show("Данные удалены");
                    EmployeesListView.ItemsSource = db.EmployeesTable.ToList();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());
                }


            }
            
        }

    }
}
