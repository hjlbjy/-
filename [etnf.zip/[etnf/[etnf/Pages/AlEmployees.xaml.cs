﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _etnf.Model;

namespace _etnf.Pages
{
    /// <summary>
    /// Логика взаимодействия для AlEmployees.xaml
    /// </summary>
    public partial class AlEmployees : Page
    {
        private EmployeesTable _currentEmployees = new EmployeesTable();
        NoEntities db;
        public AlEmployees()
        {
            InitializeComponent();
            db = new NoEntities();
            DataContext = _currentEmployees;
            Cal.ItemsSource = db.Employee_positionTable.ToList();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            db.EmployeesTable.Add(_currentEmployees); db.SaveChanges();
            MessageBox.Show("Данные сохранены");
        }
    }
}
