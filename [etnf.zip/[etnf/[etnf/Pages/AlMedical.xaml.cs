﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _etnf.Model;

namespace _etnf.Pages
{
    /// <summary>
    /// Логика взаимодействия для AlMedical.xaml
    /// </summary>
    public partial class AlMedical : Page
    {
        private Medical_checkupTable _currentMedical = new Medical_checkupTable();
        NoEntities db;
        public AlMedical()
        {
            InitializeComponent();
            db = new NoEntities();
            DataContext = _currentMedical;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            db.Medical_checkupTable.Add(_currentMedical); db.SaveChanges();
            MessageBox.Show("Данные сохранены");
        }
    }
}
