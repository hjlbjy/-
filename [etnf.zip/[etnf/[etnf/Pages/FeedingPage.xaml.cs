﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _etnf.Model;

namespace _etnf.Pages
{
    /// <summary>
    /// Логика взаимодействия для FeedingPage.xaml
    /// </summary>
    public partial class FeedingPage : Page
    {
        NoEntities db;
        public FeedingPage()
        {
            InitializeComponent();
            db = new NoEntities();
            FeedingListView.ItemsSource = db.FeedingTable.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AlFeed());
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var FeedingRemoving = FeedingListView.SelectedItems.Cast<FeedingTable>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следущие {FeedingRemoving.Count()} элементы?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    db.FeedingTable.RemoveRange(FeedingRemoving);
                    db.SaveChanges();
                    MessageBox.Show("Данные удалены");
                    FeedingListView.ItemsSource = db.FeedingTable.ToList();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());
                }


            }
        }
    }
}
